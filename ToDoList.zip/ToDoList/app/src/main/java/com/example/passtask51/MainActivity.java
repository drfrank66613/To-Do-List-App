package com.example.passtask51;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;

public class MainActivity extends AppCompatActivity {
    private ArrayList<Task> tasks;
    private ArrayList<Task> overdueTasks;
    private ArrayList<Task> nonOverdueTasks;
    private FloatingActionButton addBtn;
    private RecyclerView recyclerView;
    private TaskAdapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private MySQLiteDB database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initUI();
    }

    private void initUI(){
        addBtn = findViewById(R.id.addBtn);
        tasks = new ArrayList<>();
        overdueTasks = new ArrayList<>();
        nonOverdueTasks = new ArrayList<>();
        database = new MySQLiteDB(this, null, null, 1);
        try {
            populateTasks();
        } catch (ParseException e) {
            e.printStackTrace();
        }

        recyclerView = findViewById(R.id.recyclerView);
        layoutManager = new LinearLayoutManager(this);
        adapter = new TaskAdapter(MainActivity.this, tasks);

        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);


        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AddTaskActivity.class);
                startActivityForResult(intent, 1);
            }
        });
    }

    private void populateTasks() throws ParseException {
        if (tasks != null) {
            tasks.clear();
        }
        tasks = database.getAllPendingTasks();
        sortItems();
    }

    private void sortItems() throws ParseException {
        Comparator<Task> byDate = new Comparator<Task>() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            public int compare(Task c1, Task c2) {
                ZoneId defaultZoneId = ZoneId.systemDefault();
                Instant instant1 = c1.getTaskDate().toInstant();
                Instant instant2 = c2.getTaskDate().toInstant();
                if (instant1.atZone(defaultZoneId).toLocalDate().isBefore(instant2.atZone(defaultZoneId).toLocalDate())) return -1;
                else return 1;
            }
        };

        Collections.sort(tasks, byDate);

        for(Task task : tasks){
            if(task.getTaskDate().before(Task.dateFormat.parse(Task.dateFormat.format(new Date())))){
                overdueTasks.add(task);
            }else{
                nonOverdueTasks.add(task);
            }
        }
        tasks.clear();
        tasks.addAll(nonOverdueTasks);
        tasks.addAll(overdueTasks);

        nonOverdueTasks.clear();
        overdueTasks.clear();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.completed_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        Intent intent = new Intent(MainActivity.this, CompletedTaskActivity.class);
        startActivity(intent);
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == 1){
            if(resultCode == RESULT_OK){
                Task newTask = data.getParcelableExtra("New Task");
                database.addTask(newTask);
                try {
                    tasks = database.getAllPendingTasks();
                    sortItems();
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                adapter.setNewList(tasks);
                adapter.notifyDataSetChanged();
            }
        }
        else if(requestCode == 2){
            if(resultCode == RESULT_OK){
                Task editedTask = data.getParcelableExtra("Edit Task");
                database.updateTask(editedTask);
                try {
                    tasks = database.getAllPendingTasks();
                    sortItems();
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                adapter.setNewList(tasks);
                adapter.notifyDataSetChanged();
            }
        }
    }
}