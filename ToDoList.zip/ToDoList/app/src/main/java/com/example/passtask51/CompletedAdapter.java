package com.example.passtask51;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.SwitchCompat;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class CompletedAdapter extends RecyclerView.Adapter<CompletedAdapter.CompletedViewHolder> {

    Context context;
    ArrayList<Task> completedTasks;

    public CompletedAdapter(Context context, ArrayList<Task> completedTasks) {
        this.context = context;
        this.completedTasks = completedTasks;
    }

    public void setCompletedTasks(ArrayList<Task> completedTasks) {
        this.completedTasks = completedTasks;
    }

    @NonNull
    @Override
    public CompletedViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_layout_completed, parent, false);
        CompletedViewHolder viewHolder = new CompletedViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull CompletedAdapter.CompletedViewHolder holder, int position) {

        Task completedTask = completedTasks.get(position);
        holder.completedTaskTitle.setText(completedTask.getTaskTitle());
        holder.completedTaskDate.setText(Task.dateFormat.format(completedTask.getTaskDate()));
        holder.completedSwitchBtn.setChecked(true);
        holder.completedSwitchBtn.setText(completedTask.getTaskStatus().name());
        holder.completedSwitchBtn.setEnabled(false);

    }

    @Override
    public int getItemCount() {
        return completedTasks.size();
    }

    public class CompletedViewHolder extends RecyclerView.ViewHolder {
        public TextView completedTaskTitle, completedTaskDate;
        public Switch completedSwitchBtn;
        public ConstraintLayout completedRow_layout;

        public CompletedViewHolder(@NonNull View itemView) {
            super(itemView);
            completedTaskTitle = itemView.findViewById(R.id.completed_title);
            completedTaskDate = itemView.findViewById(R.id.completed_date);
            completedSwitchBtn = itemView.findViewById(R.id.completed_switchBtn);
            completedRow_layout = itemView.findViewById(R.id.row_layout_completed);
        }
    }
}
