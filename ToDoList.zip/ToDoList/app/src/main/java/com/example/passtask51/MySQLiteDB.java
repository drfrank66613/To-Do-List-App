package com.example.passtask51;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MySQLiteDB extends SQLiteOpenHelper {
    private static final String DB = "ToDoList";
    private static final String TABLE = "Tasks";

    private static final String ID = "id";
    private static final String TITLE = "title";
    private static final String DATE = "date";
    private static final String PRIORITY = "priority";
    private static final String STATUS = "status";
    private static final String DETAILS = "details";

    public MySQLiteDB(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DB, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String create_table = "CREATE TABLE " + TABLE + " (" +
                ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                TITLE + " TEXT, " + DATE + " TEXT, " +
                PRIORITY + " TEXT, " + STATUS + " TEXT, " +
                DETAILS + " TEXT)";

        db.execSQL(create_table);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE);
        onCreate(db);
    }

    public long addTask (Task task) {
        SQLiteDatabase database = this.getWritableDatabase();

        ContentValues val = new ContentValues();
        val.put(TITLE, task.getTaskTitle());
        val.put(DATE, Task.dateFormat.format(task.getTaskDate()));
        val.put(PRIORITY, task.getTaskPriority().name());
        val.put(STATUS, task.getTaskStatus().name());
        val.put(DETAILS, task.getTaskDetails());

        return database.insert(TABLE, null, val);
    }

    public ArrayList<Task> getAllPendingTasks() throws ParseException {
        ArrayList<Task> tasks = new ArrayList<>();
        String query = "SELECT * FROM " + TABLE + " WHERE status = ?";

        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.rawQuery(query, new String[] {Task.TaskStatus.PENDING.name()});

        if (cursor.moveToFirst()) {
            do {
                Task task = new Task();
                task.setTaskId(Integer.parseInt(cursor.getString(0)));
                task.setTaskTitle(cursor.getString(1));
                task.setTaskDate(Task.dateFormat.parse(cursor.getString(2)));
                task.setTaskPriority(Task.TaskPriority.valueOf(cursor.getString(3)));
                task.setTaskStatus(Task.TaskStatus.valueOf(cursor.getString(4)));
                task.setTaskDetails(cursor.getString(5));

                tasks.add(task);
            } while (cursor.moveToNext());
        }
        return tasks;
    }

    public ArrayList<Task> getAllCompletedTasks() throws ParseException {
        ArrayList<Task> tasks = new ArrayList<>();
        String sql = "SELECT * FROM " + TABLE + " WHERE status = ?";

        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.rawQuery(sql, new String[] {Task.TaskStatus.COMPLETED.name()});

        if (cursor.moveToFirst()) {
            do {
                Task task = new Task();
                task.setTaskId(Integer.parseInt(cursor.getString(0)));
                task.setTaskTitle(cursor.getString(1));
                task.setTaskDate(Task.dateFormat.parse(cursor.getString(2)));
                task.setTaskPriority(Task.TaskPriority.valueOf(cursor.getString(3)));
                task.setTaskStatus(Task.TaskStatus.valueOf(cursor.getString(4)));
                task.setTaskDetails(cursor.getString(5));

                tasks.add(task);
            } while (cursor.moveToNext());
        }
        return tasks;
    }

    public int removeTask(Task task) {
        SQLiteDatabase database = this.getWritableDatabase();
        return database.delete(TABLE, ID + "=?", new String[] {String.valueOf(task.getTaskId())});
    }

    public int updateTask(Task task) {
        SQLiteDatabase database = this.getWritableDatabase();

        ContentValues val = new ContentValues();
        val.put(TITLE, task.getTaskTitle());
        val.put(DATE, Task.dateFormat.format(task.getTaskDate()));
        val.put(DETAILS, task.getTaskDetails());
        val.put(PRIORITY, task.getTaskPriority().name());
        val.put(STATUS, task.getTaskStatus().name());

        return database.update(TABLE, val, "id=?", new String[] {String.valueOf(task.getTaskId())});
    }
}
