package com.example.passtask51;

import android.os.Parcel;
import android.os.Parcelable;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Task implements Parcelable {
    private int taskId;
    private String taskTitle, taskDetails;
    private Date taskDate;
    private TaskPriority taskPriority;
    private TaskStatus taskStatus;

    public static SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");

    public Task(String taskTitle, Date taskDate, TaskPriority taskPriority, TaskStatus taskStatus, String taskDetails) {
        this.taskTitle = taskTitle;
        this.taskDate = taskDate;
        this.taskPriority = taskPriority;
        this.taskStatus = taskStatus;
        this.taskDetails = taskDetails;
    }

    public Task(int taskId, String taskTitle, Date taskDate, String taskPriority, String taskStatus, String taskDetails) {
        this.taskId = taskId;
        this.taskTitle = taskTitle;
        this.taskDate = taskDate;
        this.taskPriority = TaskPriority.valueOf(taskPriority);
        this.taskStatus = TaskStatus.valueOf(taskStatus);
        this.taskDetails = taskDetails;
    }

    public Task(){

    }

    enum TaskPriority{
        IMPORTANT,
        NORMAL
    }

    enum TaskStatus{
        PENDING,
        COMPLETED
    }

    protected Task(Parcel in) throws ParseException {
        taskId = in.readInt();
        taskTitle = in.readString();
        taskDate = dateFormat.parse(in.readString());
        taskPriority = TaskPriority.valueOf(in.readString());
        taskStatus = TaskStatus.valueOf(in.readString());
        taskDetails = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(taskId);
        dest.writeString(taskTitle);
        dest.writeString(dateFormat.format(taskDate));
        dest.writeString(taskPriority.name());
        dest.writeString(taskStatus.name());
        dest.writeString(taskDetails);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Task> CREATOR = new Creator<Task>() {
        @Override
        public Task createFromParcel(Parcel in) {
            try {
                return new Task(in);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        public Task[] newArray(int size) {
            return new Task[size];
        }
    };

    public int getTaskId() {
        return taskId;
    }

    public void setTaskId(int taskId) {
        this.taskId = taskId;
    }

    public String getTaskDetails() {
        return taskDetails;
    }

    public void setTaskDetails(String taskDetails) {
        this.taskDetails = taskDetails;
    }

    public String getTaskTitle() {
        return taskTitle;
    }

    public void setTaskTitle(String taskTitle) {
        this.taskTitle = taskTitle;
    }

    public Date getTaskDate() {
        return taskDate;
    }

    public void setTaskDate(Date taskDate) {
        this.taskDate = taskDate;
    }

    public TaskPriority getTaskPriority() {
        return taskPriority;
    }

    public void setTaskPriority(TaskPriority taskPriority) {
        this.taskPriority = taskPriority;
    }

    public TaskStatus getTaskStatus() {
        return taskStatus;
    }

    public void setTaskStatus(TaskStatus taskStatus) {
        this.taskStatus = taskStatus;
    }
}


