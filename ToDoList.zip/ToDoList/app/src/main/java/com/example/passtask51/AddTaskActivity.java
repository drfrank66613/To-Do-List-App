package com.example.passtask51;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class AddTaskActivity extends AppCompatActivity implements DatePickerDialog.OnDateSetListener {
    private EditText title, details;
    private TextView date;
    private CheckBox priority;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);
        initUI();
    }

    private void initUI(){
        title = findViewById(R.id.title_editText);
        date = findViewById(R.id.date_picker);
        details = findViewById(R.id.details_editText);
        priority = findViewById(R.id.priority_checkBox);

        setCalender();
    }

    private boolean checkRequiredFields(){
        if(title.getText().toString().matches("") || date.getText().toString().matches("")){
            return false;
        }
        return true;
    }

    private void setCalender(){
        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDatePickerDialog();
            }
        });
    }

    private void showDatePickerDialog(){
        Calendar cal = Calendar.getInstance();
        DatePickerDialog datePickerDialog = new DatePickerDialog(this, this,
                Calendar.getInstance().get(Calendar.YEAR),
                Calendar.getInstance().get(Calendar.MONTH),
                Calendar.getInstance().get(Calendar.DAY_OF_MONTH));
        datePickerDialog.show();
    }

    @Override
    public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month, dayOfMonth);

        String dateStr = Task.dateFormat.format(calendar.getTime());

        date.setText(dateStr);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.submit_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(!checkRequiredFields()){
            Toast.makeText(this, "Fill in \"What to be done?\" and \"Choose When is it due?\" to proceed", Toast.LENGTH_LONG).show();
        }else{
            Task taskAdded = new Task();
            taskAdded.setTaskTitle(title.getText().toString());
            taskAdded.setTaskDetails(details.getText().toString());
            taskAdded.setTaskStatus(Task.TaskStatus.PENDING);

            if(priority.isChecked()){
                taskAdded.setTaskPriority(Task.TaskPriority.IMPORTANT);
            }else{
                taskAdded.setTaskPriority(Task.TaskPriority.NORMAL);
            }

            try {
                taskAdded.setTaskDate(Task.dateFormat.parse(date.getText().toString()));
            } catch (ParseException e) {
                e.printStackTrace();
            }

            Intent intent = new Intent();
            intent.putExtra("New Task", taskAdded);
            setResult(RESULT_OK, intent);
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}