package com.example.passtask51;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskViewHolder> {
    private MySQLiteDB database;
    private Context context;
    private ArrayList<Task> tasks;

    public TaskAdapter(Context context, ArrayList<Task> tasks) {
        this.context = context;
        this.tasks = tasks;
        this.database = new MySQLiteDB(context, null, null, 1);
    }

    public void setNewList(ArrayList<Task> tasks) {
        this.tasks = tasks;
    }

    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_layout, parent, false);
        TaskViewHolder viewHolder = new TaskViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull TaskAdapter.TaskViewHolder holder, int position) {
        Task task = tasks.get(position);

        holder.taskTitle.setText(task.getTaskTitle());
        holder.taskDate.setText(Task.dateFormat.format(task.getTaskDate()));
        holder.switchBtn.setText(task.getTaskStatus().toString());

        if(task.getTaskStatus() == Task.TaskStatus.PENDING){
            holder.switchBtn.setChecked(false);
        }else{
            holder.switchBtn.setChecked(true);
        }

        try {
            if(task.getTaskDate().before(Task.dateFormat.parse(Task.dateFormat.format(new Date())))){
                holder.row_layout.setBackgroundResource(R.color.light_pink);
                holder.taskDate.setCompoundDrawablesWithIntrinsicBounds(R.drawable.red_calendar_icon, 0, 0, 0);
            }else{
                if(task.getTaskPriority() == Task.TaskPriority.IMPORTANT){
                    holder.row_layout.setBackgroundResource(R.color.yellow);
                }else{
                    holder.row_layout.setBackgroundResource(R.color.white);
                }
                holder.taskDate.setCompoundDrawablesWithIntrinsicBounds(R.drawable.blue_calendar_icon, 0, 0, 0);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }

        holder.switchBtn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(compoundButton.isChecked()){
                    Task tempTask = task;
                    holder.switchBtn.setText(Task.TaskStatus.COMPLETED.name());
                    tempTask.setTaskStatus(Task.TaskStatus.COMPLETED);
                    database.updateTask(tempTask);

                    tasks.remove(position);
                    notifyItemRemoved(position);
                    notifyItemRangeChanged(position, tasks.size());
                }else{
                    holder.switchBtn.setText(Task.TaskStatus.PENDING.name());
                }
            }
        });

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, EditTaskActivity.class);
                intent.putExtra("Edit Task", task);
                ((Activity)context).startActivityForResult(intent, 2);
            }
        });

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                promptAlert(position);
                return true;
            }
        });
    }

    private void promptAlert(int position) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);

        alertDialogBuilder.setTitle("Remove Task");
        alertDialogBuilder
                .setPositiveButton("Remove",new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        Task tempTask = tasks.get(position);

                        database.removeTask(tempTask);
                        tasks.remove(position);
                        notifyItemRemoved(position);
                        notifyItemRangeChanged(position, tasks.size());
                    }
                })
                .setNegativeButton("Cancel",new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                })
                .setCancelable(false)
                .setMessage("Do you want to remove this task?");

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    @Override
    public int getItemCount() {
        return tasks.size();
    }

    public class TaskViewHolder extends RecyclerView.ViewHolder {
        TextView taskTitle, taskDate;
        Switch switchBtn;
        ConstraintLayout row_layout;

        public TaskViewHolder(@NonNull View itemView) {
            super(itemView);
            taskTitle = itemView.findViewById(R.id.taskTitle);
            taskDate = itemView.findViewById(R.id.date);
            switchBtn = itemView.findViewById(R.id.switchBtn);
            row_layout = itemView.findViewById(R.id.row_layout);
        }
    }


}
