package com.example.passtask51;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.text.ParseException;
import java.util.ArrayList;

public class CompletedTaskActivity extends AppCompatActivity {
    private CompletedAdapter completedAdapter;
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    private ArrayList<Task> completedTasks;
    private MySQLiteDB database;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_completed_task);
        initUI();

    }

    private void initUI() {
        database = new MySQLiteDB(this, null, null, 1);
        recyclerView = findViewById(R.id.completed_recyclerView);
        layoutManager = new LinearLayoutManager(this);

        try {
            completedTasks = database.getAllCompletedTasks();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        completedAdapter = new CompletedAdapter(this, completedTasks);

        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(completedAdapter);
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (completedTasks != null) {
            completedTasks.clear();
        }
        try {
            completedTasks = database.getAllCompletedTasks();
        } catch (ParseException e) {
            e.printStackTrace();
        }

        completedAdapter.setCompletedTasks(completedTasks);
        completedAdapter.notifyDataSetChanged();
    }
}